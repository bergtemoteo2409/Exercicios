package modelo;

public class Conta {
	private Double saldo;
	public Conta(double saldo) {
		super( );
		this.saldo = saldo;
	}
	
	public double getSaldo( ) {
		return saldo;
	}
}
