package modelo;

public interface Tributavel {
	double calcularTributos( );

}
