package modelo;

public class SeguroDeVida implements Tributavel {
	
	@Override
	public double calcularTributos( ) {
		return 42;
		
	}
}